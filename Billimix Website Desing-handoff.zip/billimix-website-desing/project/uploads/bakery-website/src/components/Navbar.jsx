import { useState, useEffect } from 'react'
import { Link, NavLink } from 'react-router-dom'

const links = [
  { to: '/', label: 'Home' },
  { to: '/menu', label: 'Menu' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <nav
      className="sticky top-0 z-50 transition-all duration-500"
      style={{
        background: scrolled ? 'rgba(250,250,247,0.88)' : 'rgba(250,250,247,0.96)',
        backdropFilter: 'blur(20px) saturate(1.6)',
        WebkitBackdropFilter: 'blur(20px) saturate(1.6)',
        borderBottom: scrolled ? '1px solid rgba(201,184,154,0.25)' : '1px solid rgba(232,224,213,0.8)',
        boxShadow: scrolled ? '0 1px 32px rgba(26,18,9,0.06)' : 'none',
      }}
    >
      <div className="max-w-screen-xl mx-auto px-6 sm:px-10 md:px-12 lg:px-18 h-[68px] flex items-center justify-between">

        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="flex flex-col leading-none">
            <span
              className="text-[20px] text-[#1A1209] tracking-[-0.01em] transition-colors duration-300 group-hover:text-[#6B3F2A]"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500 }}
            >
              Billmix
            </span>
            <span className="text-[8.5px] tracking-[0.28em] uppercase text-[#9B8E82] mt-[-1px]">Bakery</span>
          </div>
        </Link>

        {/* Desktop nav */}
        <ul className="hidden md:flex items-center gap-10">
          {links.map((link) => (
            <li key={link.to}>
              <NavLink
                to={link.to}
                end={link.to === '/'}
                className={({ isActive }) =>
                  `text-[12.5px] tracking-[0.04em] transition-colors duration-200 relative group ${
                    isActive ? 'text-[#1A1209]' : 'text-[#9B8E82] hover:text-[#1A1209]'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    {link.label}
                    <span
                      className="absolute -bottom-0.5 left-0 h-px bg-[#1A1209] transition-all duration-300"
                      style={{ width: isActive ? '100%' : '0%' }}
                    />
                    {!isActive && (
                      <span className="absolute -bottom-0.5 left-0 h-px bg-[#C9B89A] w-0 group-hover:w-full transition-all duration-300" />
                    )}
                  </>
                )}
              </NavLink>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href="https://wa.me/919039978297"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden md:inline-flex items-center gap-2.5 group text-[12.5px] font-medium tracking-[0.06em] bg-[#1A1209] text-[#FAFAF7] px-6 py-2.5 transition-all duration-300 hover:bg-[#6B3F2A] hover:shadow-lg hover:shadow-[#1A1209]/20 hover:-translate-y-px"
        >
          Order Now
          <span className="group-hover:translate-x-0.5 transition-transform duration-200 text-[#9B8E82]">→</span>
        </a>

        {/* Hamburger */}
        <button
          className="md:hidden text-[#1A1209] p-2 -mr-1 hover:text-[#6B3F2A] transition-colors duration-200"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          <div className="w-5 flex flex-col gap-[5px]">
            <span
              className="h-px bg-current transition-all duration-300 origin-center"
              style={{ transform: open ? 'translateY(6px) rotate(45deg)' : 'none' }}
            />
            <span
              className="h-px bg-current transition-all duration-300"
              style={{ opacity: open ? 0 : 1, transform: open ? 'scaleX(0)' : 'none' }}
            />
            <span
              className="h-px bg-current transition-all duration-300 origin-center"
              style={{ transform: open ? 'translateY(-6px) rotate(-45deg)' : 'none' }}
            />
          </div>
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className="md:hidden overflow-hidden transition-all duration-400"
        style={{ maxHeight: open ? '320px' : '0', opacity: open ? 1 : 0 }}
      >
        <div className="border-t border-[#E8E0D5]/60 bg-[#FAFAF7]/95 px-6 py-6 flex flex-col gap-1">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `text-[13px] tracking-[0.04em] py-3 border-b border-[#E8E0D5]/50 ${
                  isActive ? 'text-[#1A1209] font-medium' : 'text-[#9B8E82]'
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
          <a
            href="https://wa.me/919039978297"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setOpen(false)}
            className="mt-3 inline-flex items-center justify-center gap-2 bg-[#1A1209] text-[#FAFAF7] text-[13px] font-medium tracking-[0.06em] px-6 py-3.5 hover:bg-[#6B3F2A] transition-colors"
          >
            Order Now →
          </a>
        </div>
      </div>
    </nav>
  )
}
