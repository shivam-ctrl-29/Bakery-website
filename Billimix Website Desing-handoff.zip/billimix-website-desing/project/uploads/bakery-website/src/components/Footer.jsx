import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="bg-[#1A1209] text-[#FAFAF7] relative overflow-hidden">
      {/* Subtle background accent */}
      <div
        className="absolute bottom-0 left-0 w-[500px] h-[300px] pointer-events-none opacity-[0.03]"
        style={{ background: 'radial-gradient(circle at 20% 80%, #FAFAF7 0%, transparent 70%)' }}
      />

      <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 md:px-12 lg:px-18 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pb-12 border-b border-[#FAFAF7]/8">

          <div>
            <p
              className="text-[22px] text-[#FAFAF7] mb-1 tracking-[-0.01em]"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
            >
              Billmix
            </p>
            <p className="text-[8.5px] tracking-[0.28em] uppercase text-[#6B3F2A] mb-6">Bakery · Est. 2024</p>
            <p className="text-[12.5px] text-[#9B8E82] leading-relaxed max-w-xs">
              Home-made, eggless bakes crafted fresh in Indore. Every order is made to order, 24 hours in advance.
            </p>
          </div>

          <div>
            <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#6B3F2A] mb-6">Pages</p>
            <ul className="space-y-3.5">
              {[['/', 'Home'], ['/menu', 'Menu'], ['/about', 'About'], ['/contact', 'Contact']].map(([to, label]) => (
                <li key={to}>
                  <Link
                    to={to}
                    className="text-[12.5px] text-[#9B8E82] hover:text-[#FAFAF7] transition-colors duration-200 group inline-flex items-center gap-1.5"
                  >
                    <span className="opacity-0 group-hover:opacity-100 text-[#6B3F2A] transition-opacity duration-200">›</span>
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#6B3F2A] mb-6">Contact</p>
            <ul className="space-y-3.5 text-[12.5px] text-[#9B8E82]">
              <li>
                <a href="tel:+919039978297" className="hover:text-[#FAFAF7] transition-colors duration-200">
                  +91 90399 78297
                </a>
              </li>
              <li>AM 120 Sukhliya, Indore, MP</li>
              <li>
                <a
                  href="https://instagram.com/thedarshil19"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#FAFAF7] transition-colors duration-200"
                >
                  @thedarshil19
                </a>
              </li>
              <li>
                <a
                  href="https://wa.me/919039978297"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#FAFAF7] transition-colors duration-200"
                >
                  WhatsApp to Order
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-8">
          <p className="text-[11px] text-[#9B8E82]/40">
            © {new Date().getFullYear()} Billmix Bakery · All rights reserved.
          </p>
          <a
            href="https://wa.me/919039978297"
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-2 text-[11px] text-[#9B8E82]/50 hover:text-[#9B8E82] transition-colors duration-200"
          >
            Order on WhatsApp
            <span className="group-hover:translate-x-0.5 transition-transform duration-200">→</span>
          </a>
        </div>
      </div>
    </footer>
  )
}
