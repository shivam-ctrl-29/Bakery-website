import tiramisu from '../assets/tiramisu.jpeg'
import cookie from '../assets/cookie.jpg'
import bananaBread from '../assets/banana-bread.jpg'
import hummus from '../assets/hummus.jpg'
import { useScrollReveal } from '../hooks/useScrollReveal'

const menu = [
  {
    category: 'Hummus',
    items: [
      { name: 'Classic',      desc: 'A Mediterranean staple made the traditional way — smooth, rich, and endlessly versatile.', img: hummus },
      { name: 'Basil Blend',  desc: 'Creamy hummus blended with fresh basil and extra virgin olive oil.', img: hummus },
      { name: 'Roasted Peri', desc: 'Slow roasted garlic with a spicy peri peri finish. Bold and addictive.', img: hummus },
    ],
  },
  {
    category: 'Sweet Treats',
    items: [
      { name: 'Tiramisu',     desc: 'Espresso soaked eggless ladyfingers layered with silky mascarpone. Pure indulgence.', img: tiramisu },
      { name: 'Banana Bread', desc: 'Warm cinnamon spice meets delicate banana in this perfectly moist tea cake.', img: bananaBread },
      { name: 'Cookie 411',   desc: 'Soft centred, chocolate studded, with the warm nutty richness of brown butter.', img: cookie },
    ],
  },
]

function MenuItem({ item, index }) {
  const [ref, visible] = useScrollReveal(0.06)
  return (
    <div
      ref={ref}
      className="group"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(32px)',
        transition: `opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1) ${index * 100}ms, transform 0.85s cubic-bezier(0.22, 1, 0.36, 1) ${index * 100}ms`,
      }}
    >
      <div className="relative overflow-hidden bg-[#EDE6DB] mb-5" style={{ aspectRatio: '4/3' }}>
        <img
          src={item.img}
          alt={item.name}
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.05] transition-transform duration-700 ease-out"
        />
      </div>
      <h3
        className="text-[19px] text-[#1A1209] mb-2 leading-snug"
        style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
      >
        {item.name}
      </h3>
      <p className="text-[12.5px] text-[#9B8E82] leading-relaxed">{item.desc}</p>
    </div>
  )
}

export default function Menu() {
  const [headerRef, headerVisible] = useScrollReveal(0.1)

  return (
    <main className="max-w-screen-xl mx-auto px-6 sm:px-10 md:px-12 lg:px-18 py-16 md:py-24">

      {/* Header */}
      <div
        ref={headerRef}
        style={{
          opacity: headerVisible ? 1 : 0,
          transform: headerVisible ? 'translateY(0)' : 'translateY(28px)',
          transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
        }}
        className="mb-16 md:mb-20 border-b border-[#E8E0D5] pb-12"
      >
        <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#9B8E82] mb-5">What we make</p>
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <h1
            className="text-[clamp(3rem,6vw,5rem)] text-[#1A1209] leading-none tracking-[-0.02em]"
            style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
          >
            Menu
          </h1>
          <p className="text-[13px] text-[#9B8E82] max-w-xs leading-relaxed">
            Everything made fresh, to order. 100% eggless.
            Place your order at least 24 hours in advance.
          </p>
        </div>
      </div>

      {/* Categories */}
      <div className="space-y-20 md:space-y-28">
        {menu.map((section) => (
          <div key={section.category}>
            <div className="flex items-center gap-8 mb-12">
              <h2
                className="text-[22px] md:text-[27px] text-[#1A1209] shrink-0 tracking-[-0.01em]"
                style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
              >
                {section.category}
              </h2>
              <div className="flex-1 h-px bg-[#E8E0D5]" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-7 md:gap-10">
              {section.items.map((item, i) => (
                <MenuItem key={item.name} item={item} index={i} />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Notes + CTA */}
      <div className="mt-20 md:mt-28 pt-10 border-t border-[#E8E0D5] flex flex-col sm:flex-row sm:items-center justify-between gap-8">
        <div className="space-y-2">
          <p className="text-[12.5px] text-[#9B8E82]">✦ All products are 100% eggless, no exceptions.</p>
          <p className="text-[12.5px] text-[#9B8E82]">✦ Please order at least 24 hours before your desired delivery date.</p>
        </div>
        <a
          href="https://wa.me/919039978297"
          target="_blank"
          rel="noopener noreferrer"
          className="group shrink-0 inline-flex items-center gap-2.5 bg-[#1A1209] text-[#FAFAF7] text-[12.5px] font-medium tracking-[0.05em] px-8 py-4 hover:bg-[#6B3F2A] transition-all duration-300 hover:-translate-y-px hover:shadow-xl hover:shadow-[#1A1209]/15"
        >
          Order on WhatsApp
          <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
        </a>
      </div>

    </main>
  )
}
