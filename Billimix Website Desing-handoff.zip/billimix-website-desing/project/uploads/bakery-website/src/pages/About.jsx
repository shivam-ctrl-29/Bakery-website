import { useScrollReveal } from '../hooks/useScrollReveal'
import cookie from '../assets/cookie.jpg'

export default function About() {
  const [heroRef, heroVisible]     = useScrollReveal(0.05)
  const [storyRef, storyVisible]   = useScrollReveal(0.1)
  const [valuesRef, valuesVisible] = useScrollReveal(0.1)
  const [ctaRef, ctaVisible]       = useScrollReveal(0.2)

  return (
    <main>

      {/* ── HERO ── */}
      <section className="grid grid-cols-1 md:grid-cols-2" style={{ minHeight: '72vh' }}>
        <div
          ref={heroRef}
          style={{
            opacity: heroVisible ? 1 : 0,
            transform: heroVisible ? 'translateY(0)' : 'translateY(28px)',
            transition: 'opacity 0.9s cubic-bezier(0.22, 1, 0.36, 1), transform 0.9s cubic-bezier(0.22, 1, 0.36, 1)',
          }}
          className="flex flex-col justify-center px-6 sm:px-10 md:px-12 lg:px-18 py-16 md:py-20 order-2 md:order-1"
        >
          <div className="flex items-center gap-3 mb-8">
            <span className="w-6 h-px bg-[#C9B89A]" />
            <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#9B8E82]">Our Story</p>
          </div>
          <h1
            className="text-[clamp(2.6rem,5.5vw,5rem)] text-[#1A1209] leading-[1.05] tracking-[-0.02em] mb-8"
            style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
          >
            Made at home.<br />
            <span className="text-[#6B3F2A] italic">Made with heart.</span>
          </h1>
          <p className="text-[14.5px] text-[#9B8E82] leading-[1.8] max-w-sm">
            Billmix started in 2024 out of a simple love for honest baking. Every item is made fresh
            in a home kitchen in Sukhliya, Indore — no factory, no shortcuts, no eggs.
          </p>
        </div>
        <div className="relative h-[60vw] md:h-auto order-1 md:order-2">
          <img src={cookie} alt="Fresh baked cookies" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent" />
        </div>
      </section>

      {/* ── STORY ── */}
      <section className="border-t border-[#E8E0D5]">
        <div
          ref={storyRef}
          style={{
            opacity: storyVisible ? 1 : 0,
            transform: storyVisible ? 'translateY(0)' : 'translateY(28px)',
            transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
          }}
          className="max-w-screen-xl mx-auto px-6 sm:px-10 md:px-12 lg:px-18 py-16 md:py-24 grid grid-cols-1 md:grid-cols-3 gap-12"
        >
          <div className="md:col-span-1">
            <blockquote
              className="text-[21px] md:text-[23px] text-[#1A1209] leading-[1.5] mb-6"
              style={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', fontWeight: 400 }}
            >
              "I make food that people genuinely enjoy eating."
            </blockquote>
            <div className="flex items-center gap-3">
              <div className="w-6 h-px bg-[#C9B89A]" />
              <div>
                <p className="text-[12.5px] text-[#1A1209] font-medium">Darshil Yadav</p>
                <p className="text-[11px] text-[#9B8E82] mt-0.5">Founder · Billmix · Est. 2024</p>
              </div>
            </div>
          </div>
          <div className="md:col-span-2 space-y-5 text-[13.5px] text-[#9B8E82] leading-[1.85]">
            <p>
              Hi, I'm <span className="text-[#1A1209] font-medium">Darshil Yadav</span>, the person behind Billmix.
              This started as a passion project — I loved making food that people actually enjoyed eating.
              Not mass-produced. Not frozen. Just real, home-made bakes with good ingredients.
            </p>
            <p>
              Everything at Billmix is <span className="text-[#1A1209] font-medium">100% eggless</span>. I've spent time
              perfecting recipes that prove great baking doesn't need eggs. From a silky Tiramisu to a brown
              butter Cookie 411 — every item has had months of testing behind it.
            </p>
            <p>
              We operate out of a home kitchen in Sukhliya, Indore. Every single order gets personal attention.
              You're not a number here — you're the reason I'm baking that day.
            </p>
          </div>
        </div>
      </section>

      {/* ── VALUES ── */}
      <section className="bg-[#1A1209] relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{ backgroundImage: 'radial-gradient(circle at 80% 50%, #FAFAF7 0%, transparent 60%)' }}
        />
        <div
          ref={valuesRef}
          style={{
            opacity: valuesVisible ? 1 : 0,
            transform: valuesVisible ? 'translateY(0)' : 'translateY(28px)',
            transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
          }}
          className="relative max-w-screen-xl mx-auto px-6 sm:px-10 md:px-12 lg:px-18 py-16 md:py-24"
        >
          <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#6B3F2A] mb-14">What we stand for</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-10 md:gap-16">
            {[
              { num: '01', title: 'Always Eggless',  desc: 'Every single product — no exceptions, no compromises, no hidden ingredients.' },
              { num: '02', title: 'Home Kitchen',     desc: 'Made in a real home kitchen with genuine care, attention, and fresh ingredients.' },
              { num: '03', title: 'Made to Order',    desc: 'Nothing pre-made. Your order is baked fresh, just for you, every single time.' },
            ].map(({ num, title, desc }, i) => (
              <div
                key={num}
                className="border-t border-[#FAFAF7]/10 pt-8"
                style={{
                  opacity: valuesVisible ? 1 : 0,
                  transform: valuesVisible ? 'translateY(0)' : 'translateY(24px)',
                  transition: `opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1) ${i * 120}ms, transform 0.85s cubic-bezier(0.22, 1, 0.36, 1) ${i * 120}ms`,
                }}
              >
                <p className="text-[10px] text-[#6B3F2A] tracking-[0.2em] uppercase mb-6">{num}</p>
                <p
                  className="text-[19px] text-[#FAFAF7] mb-3 leading-snug"
                  style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
                >
                  {title}
                </p>
                <p className="text-[12.5px] text-[#9B8E82] leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section
        ref={ctaRef}
        style={{
          opacity: ctaVisible ? 1 : 0,
          transform: ctaVisible ? 'translateY(0)' : 'translateY(28px)',
          transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
        }}
        className="max-w-screen-xl mx-auto px-6 sm:px-10 md:px-12 lg:px-18 py-16 md:py-20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-8 border-b border-[#E8E0D5]"
      >
        <p
          className="text-[24px] md:text-[30px] text-[#1A1209] tracking-[-0.01em]"
          style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
        >
          Want to try something?
        </p>
        <a
          href="https://wa.me/919039978297"
          target="_blank"
          rel="noopener noreferrer"
          className="group shrink-0 inline-flex items-center gap-2.5 bg-[#1A1209] text-[#FAFAF7] text-[12.5px] font-medium tracking-[0.05em] px-8 py-4 hover:bg-[#6B3F2A] transition-all duration-300 hover:-translate-y-px hover:shadow-xl hover:shadow-[#1A1209]/15"
        >
          Order on WhatsApp
          <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
        </a>
      </section>

    </main>
  )
}
