import { Link } from 'react-router-dom'
import { useScrollReveal } from '../hooks/useScrollReveal'
import tiramisu from '../assets/tiramisu.jpeg'
import cookie from '../assets/cookie.jpg'
import bananaBread from '../assets/banana-bread.jpg'
import hummus from '../assets/hummus.jpg'

const marqueeItems = [
  '100% Eggless', 'Home Kitchen', 'Indore', 'Made to Order', '24hr Advance',
  'Tiramisu', 'Cookie 411', 'Banana Bread', 'Classic Hummus', 'Roasted Peri',
  '100% Eggless', 'Home Kitchen', 'Indore', 'Made to Order', '24hr Advance',
  'Tiramisu', 'Cookie 411', 'Banana Bread', 'Classic Hummus', 'Roasted Peri',
]

const products = [
  { name: 'Tiramisu',     label: 'Sweet Treat', img: tiramisu,    desc: 'Eggless ladyfingers, silky mascarpone, espresso.' },
  { name: 'Cookie 411',  label: 'Sweet Treat', img: cookie,       desc: 'Brown butter, chocolate studded, soft centre.' },
  { name: 'Banana Bread',label: 'Sweet Treat', img: bananaBread,  desc: 'Cinnamon spice, moist crumb, banana warmth.' },
  { name: 'Hummus',      label: 'Savoury',     img: hummus,       desc: 'Classic, Basil Blend & Roasted Peri.' },
]

function ProductCard({ item, index }) {
  const [ref, visible] = useScrollReveal(0.08)
  return (
    <div
      ref={ref}
      className="group cursor-default"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(36px)',
        transition: `opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1) ${index * 110}ms, transform 0.85s cubic-bezier(0.22, 1, 0.36, 1) ${index * 110}ms`,
      }}
    >
      <div className="relative overflow-hidden bg-[#EDE6DB] mb-5" style={{ aspectRatio: '3/4' }}>
        <img
          src={item.img}
          alt={item.name}
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.06] transition-transform duration-700 ease-out"
        />
        {/* Bottom overlay on hover */}
        <div
          className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        />
      </div>
      <p className="text-[9.5px] tracking-[0.22em] uppercase text-[#9B8E82] mb-1.5">{item.label}</p>
      <p className="font-serif text-[18px] text-[#1A1209] mb-1.5 leading-tight">{item.name}</p>
      <p className="text-[12.5px] text-[#9B8E82] leading-relaxed">{item.desc}</p>
    </div>
  )
}

export default function Home() {
  const [menuRef, menuVisible]   = useScrollReveal(0.05)
  const [storyRef, storyVisible] = useScrollReveal(0.1)
  const [ctaRef, ctaVisible]     = useScrollReveal(0.15)

  return (
    <main>

      {/* ── HERO ── */}
      <section className="grid grid-cols-1 md:grid-cols-[1fr_1fr]" style={{ minHeight: 'calc(100vh - 68px)' }}>

        {/* Left — text */}
        <div className="flex flex-col justify-center px-6 sm:px-10 md:px-12 lg:px-18 py-16 md:py-20">

          <div className="hero-label flex items-center gap-3 mb-10">
            <span className="w-6 h-px bg-[#C9B89A]" />
            <p className="text-[10px] tracking-[0.28em] uppercase text-[#9B8E82]">
              Home-made · Eggless · Indore
            </p>
          </div>

          <h1 className="font-serif leading-[1.02] mb-10" style={{ fontFamily: "'Playfair Display', serif" }}>
            <span className="hero-line-1 block text-[clamp(3.2rem,6.5vw,6rem)] text-[#1A1209] tracking-[-0.02em]">Baked</span>
            <span className="hero-line-2 block text-[clamp(3.2rem,6.5vw,6rem)] text-[#1A1209] tracking-[-0.02em]">fresh.</span>
            <span className="hero-line-3 block text-[clamp(3.2rem,6.5vw,6rem)] text-[#6B3F2A] italic tracking-[-0.01em]">Every time.</span>
          </h1>

          <p className="hero-body text-[#9B8E82] text-[14.5px] leading-[1.8] max-w-[300px] mb-10">
            Every item at Billmix is made at home in Indore — eggless, wholesome, crafted just for you.
            Order 24 hours in advance.
          </p>

          <div className="hero-btns flex flex-wrap gap-3 mb-12">
            <a
              href="https://wa.me/919039978297"
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center justify-center gap-2.5 bg-[#1A1209] text-[#FAFAF7] text-[12.5px] font-medium tracking-[0.05em] px-8 py-3.5 hover:bg-[#6B3F2A] transition-all duration-300 hover:shadow-xl hover:shadow-[#1A1209]/20 hover:-translate-y-px"
            >
              Order on WhatsApp
              <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
            </a>
            <Link
              to="/menu"
              className="group inline-flex items-center justify-center gap-2.5 border border-[#1A1209]/20 text-[#1A1209] text-[12.5px] font-medium tracking-[0.05em] px-8 py-3.5 hover:border-[#1A1209] hover:bg-[#1A1209] hover:text-[#FAFAF7] transition-all duration-300"
            >
              View Menu
              <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
            </Link>
          </div>

          <div className="hero-usps border-t border-[#E8E0D5] pt-8 grid grid-cols-2 gap-x-8 gap-y-6">
            {[
              { label: '100% Eggless',  sub: 'No exceptions, ever' },
              { label: 'Home Kitchen',  sub: 'Sukhliya, Indore' },
              { label: 'Made to Order', sub: 'Fresh every single time' },
              { label: '24hr Advance',  sub: 'Plan your treat ahead' },
            ].map(({ label, sub }) => (
              <div key={label}>
                <p className="text-[12.5px] font-medium text-[#1A1209] mb-0.5 tracking-[0.01em]">{label}</p>
                <p className="text-[11px] text-[#B0A396]">{sub}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Right — full-bleed image */}
        <div className="hero-image relative h-[75vw] md:h-auto">
          <img
            src={tiramisu}
            alt="Billmix Tiramisu"
            className="absolute inset-0 w-full h-full object-cover"
          />
          {/* Gradient */}
          <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-black/50 to-transparent" />
          <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-black/10 to-transparent" />

          {/* Glass badge */}
          <div className="hero-badge absolute bottom-7 left-7 glass px-5 py-4 rounded-sm">
            <p className="text-[9px] tracking-[0.28em] uppercase text-[#F2C07E] mb-1">Signature</p>
            <p className="font-serif text-[20px] text-[#FAFAF7] leading-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
              Tiramisu
            </p>
            <p className="text-[10.5px] text-[#FAFAF7]/60 mt-0.5">100% Eggless</p>
          </div>
        </div>

      </section>

      {/* ── MARQUEE ── */}
      <div className="border-y border-[#E8E0D5] py-4 overflow-hidden bg-[#FAF8F4]">
        <div className="marquee-track select-none">
          {marqueeItems.map((item, i) => (
            <span key={i} className="flex items-center shrink-0">
              <span className="text-[9.5px] tracking-[0.28em] uppercase text-[#C9B89A] px-7">{item}</span>
              <span className="text-[#DEDAD4] text-[8px]">◆</span>
            </span>
          ))}
        </div>
      </div>

      {/* ── OUR MENU ── */}
      <section className="px-6 sm:px-10 md:px-12 lg:px-18 py-20 md:py-28 max-w-screen-xl mx-auto">

        <div
          ref={menuRef}
          style={{
            opacity: menuVisible ? 1 : 0,
            transform: menuVisible ? 'translateY(0)' : 'translateY(28px)',
            transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
          }}
          className="flex items-end justify-between mb-14"
        >
          <div>
            <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#9B8E82] mb-3">What we make</p>
            <h2
              className="text-[clamp(2rem,4vw,3.2rem)] text-[#1A1209] leading-none tracking-[-0.02em]"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
            >
              Our Menu
            </h2>
          </div>
          <Link
            to="/menu"
            className="hidden sm:flex items-center gap-2 text-[12.5px] text-[#9B8E82] hover:text-[#1A1209] transition-colors duration-200 group"
          >
            See full menu
            <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-5 md:gap-8">
          {products.map((item, i) => (
            <ProductCard key={item.name} item={item} index={i} />
          ))}
        </div>

        <div className="sm:hidden mt-10 flex justify-center">
          <Link to="/menu" className="text-[12.5px] text-[#9B8E82] border-b border-[#C9B89A] pb-0.5">
            See full menu →
          </Link>
        </div>
      </section>

      {/* ── QUOTE / STORY ── */}
      <section
        ref={storyRef}
        style={{
          opacity: storyVisible ? 1 : 0,
          transform: storyVisible ? 'translateY(0)' : 'translateY(28px)',
          transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
        }}
        className="bg-[#F5EFE4] border-y border-[#E8E0D5]"
      >
        <div className="px-6 sm:px-10 md:px-12 lg:px-18 py-16 md:py-24 max-w-screen-xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-[2fr_1fr] gap-10 md:gap-20 items-center">
            <div>
              <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#9B8E82] mb-8">Our Story</p>
              <blockquote
                className="text-[clamp(1.3rem,2.8vw,2.1rem)] text-[#1A1209] leading-[1.45] tracking-[-0.01em] mb-8"
                style={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', fontWeight: 400 }}
              >
                "I started Billmix because I wanted to make food people genuinely love eating — eggless, honest, home-made."
              </blockquote>
              <div className="flex items-center gap-4">
                <div className="w-8 h-px bg-[#C9B89A]" />
                <div>
                  <p className="text-[12.5px] text-[#1A1209] font-medium">Darshil Yadav</p>
                  <p className="text-[11px] text-[#9B8E82]">Founder · Sukhliya, Indore</p>
                </div>
              </div>
            </div>
            <div className="flex md:justify-end">
              <Link
                to="/about"
                className="group inline-flex items-center gap-2.5 text-[12.5px] text-[#6B3F2A] border-b border-[#6B3F2A]/30 pb-0.5 hover:border-[#6B3F2A] transition-all duration-200"
              >
                Read our story
                <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section
        ref={ctaRef}
        style={{
          opacity: ctaVisible ? 1 : 0,
          transform: ctaVisible ? 'translateY(0)' : 'translateY(28px)',
          transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
        }}
        className="relative bg-[#1A1209] overflow-hidden"
      >
        {/* Decorative circle */}
        <div
          className="absolute top-0 right-0 w-[600px] h-[600px] rounded-full opacity-[0.04] pointer-events-none"
          style={{ background: 'radial-gradient(circle, #FAFAF7 0%, transparent 70%)', transform: 'translate(30%, -40%)' }}
        />
        <div className="relative px-6 sm:px-10 md:px-12 lg:px-18 py-20 md:py-28 max-w-screen-xl mx-auto flex flex-col md:flex-row items-start md:items-end justify-between gap-10">
          <div>
            <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#6B3F2A] mb-6">Ready to order?</p>
            <h2
              className="text-[clamp(2rem,4.5vw,4.2rem)] text-[#FAFAF7] leading-[1.05] tracking-[-0.02em]"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
            >
              Place your order<br />
              <span className="italic text-[#C9B89A]">at least 24 hours ahead.</span>
            </h2>
          </div>
          <a
            href="https://wa.me/919039978297"
            target="_blank"
            rel="noopener noreferrer"
            className="group shrink-0 inline-flex items-center gap-3 bg-[#FAFAF7] text-[#1A1209] text-[12.5px] font-medium tracking-[0.05em] px-10 py-4 hover:bg-[#F2C07E] transition-all duration-300 hover:shadow-2xl hover:-translate-y-0.5"
          >
            WhatsApp Us
            <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
          </a>
        </div>
      </section>

    </main>
  )
}
