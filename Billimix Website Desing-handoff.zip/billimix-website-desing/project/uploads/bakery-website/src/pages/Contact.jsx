import { useState } from 'react'
import { useScrollReveal } from '../hooks/useScrollReveal'

export default function Contact() {
  const [form, setForm] = useState({ name: '', phone: '', message: '' })
  const [sent, setSent] = useState(false)
  const [focused, setFocused] = useState(null)

  const [headerRef, headerVisible] = useScrollReveal(0.1)
  const [formRef, formVisible]     = useScrollReveal(0.05)
  const [infoRef, infoVisible]     = useScrollReveal(0.05)

  function handleChange(e) {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }))
  }

  function handleSubmit(e) {
    e.preventDefault()
    const text = `Hello Billmix!%0AName: ${form.name}%0APhone: ${form.phone}%0AMessage: ${form.message}`
    window.open(`https://wa.me/919039978297?text=${text}`, '_blank')
    setSent(true)
    setTimeout(() => setSent(false), 4000)
    setForm({ name: '', phone: '', message: '' })
  }

  const fields = [
    { id: 'name',  label: 'Your Name',    type: 'text', placeholder: 'Rahul Sharma' },
    { id: 'phone', label: 'Phone Number', type: 'tel',  placeholder: '+91 98765 43210' },
  ]

  return (
    <main className="max-w-screen-xl mx-auto px-6 sm:px-10 md:px-12 lg:px-18 py-16 md:py-24">

      {/* Header */}
      <div
        ref={headerRef}
        style={{
          opacity: headerVisible ? 1 : 0,
          transform: headerVisible ? 'translateY(0)' : 'translateY(28px)',
          transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
        }}
        className="mb-16 md:mb-20 border-b border-[#E8E0D5] pb-12"
      >
        <div className="flex items-center gap-3 mb-5">
          <span className="w-6 h-px bg-[#C9B89A]" />
          <p className="text-[9.5px] tracking-[0.28em] uppercase text-[#9B8E82]">Get in touch</p>
        </div>
        <h1
          className="text-[clamp(3rem,6vw,5rem)] text-[#1A1209] leading-none tracking-[-0.02em]"
          style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
        >
          Contact
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">

        {/* Form */}
        <div
          ref={formRef}
          style={{
            opacity: formVisible ? 1 : 0,
            transform: formVisible ? 'translateY(0)' : 'translateY(28px)',
            transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1), transform 0.85s cubic-bezier(0.22, 1, 0.36, 1)',
          }}
        >
          <h2
            className="text-[21px] text-[#1A1209] mb-10 tracking-[-0.01em]"
            style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
          >
            Send a message
          </h2>

          {sent && (
            <div className="bg-[#6B3F2A]/8 border-l-2 border-[#6B3F2A] px-5 py-4 mb-8 rounded-r-sm">
              <p className="text-[12.5px] text-[#6B3F2A] font-medium">Opening WhatsApp — we'll get back to you shortly.</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-7">
            {fields.map(({ id, label, type, placeholder }) => (
              <div key={id} className="relative">
                <label
                  htmlFor={id}
                  className="block text-[9.5px] tracking-[0.22em] uppercase mb-3 transition-colors duration-200"
                  style={{ color: focused === id ? '#1A1209' : '#9B8E82' }}
                >
                  {label}
                </label>
                <input
                  id={id}
                  name={id}
                  type={type}
                  required
                  value={form[id]}
                  onChange={handleChange}
                  onFocus={() => setFocused(id)}
                  onBlur={() => setFocused(null)}
                  placeholder={placeholder}
                  className="w-full border-b bg-transparent pb-3 text-[14px] text-[#1A1209] placeholder:text-[#D4C9BC] focus:outline-none transition-colors duration-300"
                  style={{ borderColor: focused === id ? '#1A1209' : '#E8E0D5' }}
                />
              </div>
            ))}
            <div className="relative">
              <label
                htmlFor="message"
                className="block text-[9.5px] tracking-[0.22em] uppercase mb-3 transition-colors duration-200"
                style={{ color: focused === 'message' ? '#1A1209' : '#9B8E82' }}
              >
                Message / Order Details
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                required
                value={form.message}
                onChange={handleChange}
                onFocus={() => setFocused('message')}
                onBlur={() => setFocused(null)}
                placeholder="I'd like to order a Tiramisu for delivery on..."
                className="w-full border-b bg-transparent pb-3 text-[14px] text-[#1A1209] placeholder:text-[#D4C9BC] focus:outline-none transition-colors duration-300 resize-none"
                style={{ borderColor: focused === 'message' ? '#1A1209' : '#E8E0D5' }}
              />
            </div>
            <div className="pt-2">
              <button
                type="submit"
                className="group inline-flex items-center gap-3 bg-[#1A1209] text-[#FAFAF7] text-[12.5px] font-medium tracking-[0.05em] px-8 py-4 hover:bg-[#6B3F2A] transition-all duration-300 w-full sm:w-auto justify-center hover:-translate-y-px hover:shadow-xl hover:shadow-[#1A1209]/15"
              >
                Send via WhatsApp
                <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
              </button>
            </div>
          </form>
        </div>

        {/* Info */}
        <div
          ref={infoRef}
          style={{
            opacity: infoVisible ? 1 : 0,
            transform: infoVisible ? 'translateY(0)' : 'translateY(28px)',
            transition: 'opacity 0.85s cubic-bezier(0.22, 1, 0.36, 1) 100ms, transform 0.85s cubic-bezier(0.22, 1, 0.36, 1) 100ms',
          }}
        >
          <h2
            className="text-[21px] text-[#1A1209] mb-10 tracking-[-0.01em]"
            style={{ fontFamily: "'Playfair Display', serif", fontWeight: 400 }}
          >
            Find us
          </h2>

          <div className="mb-10">
            {[
              { label: 'Phone',     value: '+91 90399 78297',           href: 'tel:+919039978297' },
              { label: 'Address',   value: 'AM 120 Sukhliya, Indore, MP', href: null },
              { label: 'Instagram', value: '@thedarshil19',               href: 'https://instagram.com/thedarshil19' },
              { label: 'WhatsApp',  value: 'WhatsApp to place an order',  href: 'https://wa.me/919039978297' },
            ].map(({ label, value, href }) => (
              <div key={label} className="flex gap-8 py-5 border-b border-[#E8E0D5] group">
                <p className="text-[9.5px] tracking-[0.2em] uppercase text-[#9B8E82] w-24 shrink-0 pt-0.5">{label}</p>
                {href ? (
                  <a
                    href={href}
                    target={href.startsWith('http') ? '_blank' : undefined}
                    rel="noopener noreferrer"
                    className="text-[13.5px] text-[#1A1209] hover:text-[#6B3F2A] transition-colors duration-200 flex items-center gap-2 group"
                  >
                    {value}
                    <span className="opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-200 text-[#9B8E82]">→</span>
                  </a>
                ) : (
                  <p className="text-[13.5px] text-[#1A1209]">{value}</p>
                )}
              </div>
            ))}
          </div>

          {/* Map */}
          <div className="overflow-hidden bg-[#E8E0D5]" style={{ height: '240px' }}>
            <iframe
              title="Billmix Bakery Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3679.7!2d75.8577!3d22.7196!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjLCsDQzJzEwLjYiTiA3NcKwNTEnMjcuNyJF!5e0!3m2!1sen!2sin!4v1"
              width="100%"
              height="100%"
              style={{ border: 0, filter: 'grayscale(40%) contrast(1.05) sepia(10%)' }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          <p className="text-[11px] text-[#C9B89A] mt-4">
            ✦ Please order at least 24 hours before your desired delivery date.
          </p>
        </div>

      </div>
    </main>
  )
}
